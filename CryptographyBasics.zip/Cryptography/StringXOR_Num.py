"""Here we have a string and a number.
We XOR each character of the string with the number and
print the resulting output."""
WordString= 'label'
OurNum = 13
#Convert both of these to binary
OurNewWordNum = [ord(x) ^ OurNum for x in WordString]
for y in OurNewWordNum:
    print(chr(y), end='')
