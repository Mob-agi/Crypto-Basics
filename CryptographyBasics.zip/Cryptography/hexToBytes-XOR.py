"""In this one we have hexadecimal string
We need to convert them to bytes before we XOR."""

KEY1 = 'a6c8b6733c9b22de7bc0253266a3867df55acde8635e19c73313'
Key1Str = bytes.fromhex(KEY1)

Key12= '37dcb292030faa90d07eec17e3b1c6d8daf94c35d4c9191a5e1e'
Key2Str = bytes.fromhex(Key12)
# XOR the Key1Str,Key2Str to find KEY2
Key2= bytes(a ^ b for a, b in zip(Key2Str, Key1Str))

KEY23 = 'c1545756687e7573db23aa1c3452a098b71a7fbf0fddddde5fc1'
Key3Str = bytes.fromhex(KEY23)
# XOR the Key1Str,Key2 to find KEY3
Key3= bytes(a ^ b for a, b in zip(Key2, Key3Str))

FLAGKEY123 = '04ee9855208a2cd59091d04767ae47963170d1660df7f56f5faf'
FlagKey123 = bytes.fromhex(FLAGKEY123)
# XOR the Key1Str,Key2, Key3, KeyFlag123 to find Flag
Flag= bytes(a ^ b ^ c ^ d for a, b, c, d in zip( Key1Str, Key3, Key2, FlagKey123))
print(Flag)